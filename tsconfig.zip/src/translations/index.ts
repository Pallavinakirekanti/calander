import english from './english';
import german from './german';
import russian from './russian';

export default { english, german, russian };
