const computeMonthlyOn = (on: any) => ({
  bymonthday: on.day
});

export default computeMonthlyOn;
